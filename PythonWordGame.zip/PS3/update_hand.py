def update_hand(hand,word):
    new_hand = hand.copy()
    
    list_word = list(word.lower())
    
    print(list_word)
    
    for letter in list_word:
        if letter in new_hand:
            new_hand[letter] = new_hand.get(letter,0) - 1 
            if(new_hand[letter]<0):
                new_hand[letter] = 0
            
    print (new_hand)
    
hand = {'j':2, 'o':1, 'l':1, 'w':1, 'n':2} #JJOLWNN
update_hand(hand,'gone')
