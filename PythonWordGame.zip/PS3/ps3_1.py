import math
import random
import string
import random

VOWELS = 'aeiou'
CONSONANTS = 'bcdfghjklmnpqrstvwxyz'
HAND_SIZE = 7

SCRABBLE_LETTER_VALUES = {
    'a': 1, 'b': 3, 'c': 3, 'd': 2, 'e': 1, 'f': 4, 'g': 2, 'h': 4, 'i': 1, 'j': 8, 'k': 5, 'l': 1, 'm': 3, 'n': 1, 'o': 1, 'p': 3, 'q': 10, 'r': 1, 's': 1, 't': 1, 'u': 1, 'v': 4, 'w': 4, 'x': 8, 'y': 4, 'z': 10
}

VOWELS = ['a','e','i','o','u']


def load_words():
    
    print("Loading word list from file...")
    # inFile: file
    inFile = open('words.txt', 'r')
    # wordlist: list of strings
    wordlist = []
    for line in inFile:
        wordlist.append(line.strip().lower())
    print("  ", len(wordlist), "words loaded.")
    return wordlist

def calculate_handlen(hand):
    

    handlen = 0
    for i in hand:
        handlen = handlen + hand[i]
    return handlen

def substitute_hand(hand, letter):
    letters = 'aeioubcdfghjklmnpqrstvwxyz'
    
    if letter not in hand:
        return hand
    else:
        to_pick = []
        freq = hand[letter]
        del(hand[letter])
        for i in letters:
            if i not in hand:
                to_pick.append(i)
    
        new_element = random.choice(to_pick)
        hand[new_element] = freq
            
    return hand
    

def get_word_score(word, n): 
    #n = No. of letters availaible in the current hand
    #word = the word which we have to calculate the score for
    SCRABBLE_LETTER_VALUES = {
    'a': 1, 'b': 3, 'c': 3, 'd': 2, 'e': 1, 'f': 4, 'g': 2, 'h': 4, 'i': 1, 'j': 8, 'k': 5, 'l': 1, 'm': 3, 'n': 1, 'o': 1, 'p': 3, 'q': 10, 'r': 1, 's': 1, 't': 1, 'u': 1, 'v': 4, 'w': 4, 'x': 8, 'y': 4, 'z': 10,'*' :0}   
    word = word.lower()
    list_word = list(word)
    component_one = 0 
    for a in list_word:
        component_one = component_one + SCRABBLE_LETTER_VALUES[a]
    
    component_two =(7 * len(word)) - (3* (n-len(word)))
    
    if (component_two < 1):
        component_two = 1
    
    score = component_one * component_two
    return score

def deal_hand(n): 
    hand={}
    num_vowels = int(math.ceil(n / 3))

    for i in range(num_vowels):
        x = random.choice(VOWELS)
        hand[x] = hand.get(x, 0) + 1
    
    for i in range(num_vowels, n):    
        x = random.choice(CONSONANTS)
        hand[x] = hand.get(x, 0) + 1
    
    return hand

def get_frequency_dict(sequence):
    
    freq = {}
    for x in sequence:
        freq[x] = freq.get(x,0) + 1
    return freq

def update_hand(hand,word):
    new_hand = hand.copy()
    
    list_word = list(word.lower())
    
    print(list_word)
    
    for letter in list_word:
        if letter in new_hand:
            new_hand[letter] = new_hand.get(letter,0) - 1 
            if(new_hand[letter]<0):
                new_hand[letter] = 0
            
    return (new_hand)

def display_hand(hand):  
    print' Current Hand is ---->  ',
    for letter in hand.keys():

        for j in range(hand[letter]):
             print letter,
    print ' '    # print all on the same line
      # print an empty line

def is_valid_word(word,hand,word_list):
    list_of_words = list(word)
    if '*' in word:
        wildCardPos = word.find('*')
        print"Wildcard found at : ", wildCardPos
           
        for wildcard in VOWELS: #wildcard takes a value of a,e,i,o,u
            list_of_words[wildCardPos] = wildcard
            new_word = ''.join(list_of_words)       
            frequency_dict_word = get_frequency_dict(new_word)       
            if new_word in word_list:
                for i in new_word:
                    if frequency_dict_word.get(i,0) <= hand.get(i,0):
                        return True
                    else:
                        return False
            else:
                return False
    else:
        if word in word_list:
            frequency_dict_word = get_frequency_dict(word)  
            for i in word:
                if frequency_dict_word.get(i,0) <= hand.get(i,0):
                    return True
                else:
                    return False
        else:
            return False
    
    
def play_hand(hand, word_list):
    score = 0
    while ( calculate_handlen(hand) > 0):
        display_hand(hand)
        word = raw_input("Enter a word or enter '!!' to indicate that you have finished... -->  ")
    
        if (word == '!!'):
            break
        else:
            if(is_valid_word(word, hand, word_list) == True):
                score = score + get_word_score(word, calculate_handlen(hand))
                print' The word you entered is Valid.. The score is', get_word_score(word, calculate_handlen(hand))
            else:
                print' The word you entered is invalid.. Enter another word'
            
            hand = update_hand(hand, word)
        
    return score



def play_game(word_list):
    HAND_SIZE = 7
    total_score = 0
    substite_counter = 0
    replay_counter = 0 
    t = 1
    number_of_hands = input("Enter the number of hands you want to play.... -->  ")
    while(number_of_hands > 0):
        print ' <----------------------------------------------->'
        print "Playing Hand : ", t
        hand = deal_hand(HAND_SIZE)
        display_hand(hand)
        if(substite_counter==0):     
            input_by_user = raw_input("Do you want to Substitute some letter for another letter? (Only allowed for one time)  ---->  ")
            if(input_by_user == 'Yes'):      
                letter_in = raw_input('Enter the letter you want to substitute. ----> ')
                hand = substitute_hand(hand, letter_in)
                substite_counter = substite_counter + 1
                
        current_score = play_hand(hand, word_list)
        total_score = total_score + current_score
        
        if(replay_counter == 0):
            replay = raw_input("Do you want to Replay the Hand ? Enter Yes/No (Only allowed for one time)")
          
        if ( replay == 'Yes' and replay_counter == 0):
            number_of_hands = number_of_hands + 1
            replay_counter = replay_counter + 1
            replay_score = play_hand(hand,word_list)
            if(replay_score > current_score):
                total_score = total_score + replay_score
            else:
                total_score = total_score + current_score
                
        current_score  = 0                
        t = t+1
        number_of_hands = number_of_hands - 1
    
    return total_score
word_list = load_words()
score_1 = play_game(word_list)
print score_1               
            
