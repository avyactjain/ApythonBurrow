def play_hand(hand, word_list):
    score = 0
    while ( calculate_handlen(hand) > 0):
        display_hand(hand)
        word = raw_input("Enter a word or enter '!!' to indicate that you have finished... -->  ")
    
        if (word == '!!'):
            break
        else:
            if(is_valid_word(word, hand, word_list) == True):
                score = score + get_word_score(word, calculate_handlen(hand))
                print' The word you entered is Valid.. The score is', get_word_score(word, calculate_handlen(hand))
            else:
                print' The word you entered is invalid.. Enter another word'
            
            hand = update_hand(hand, word)
        
    return score