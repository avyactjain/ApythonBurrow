def is_valid_word(word,hand,word_list):
    frequency_dict_word = get_frequency_dict(word)       
    if word in word_list:
        for i in word:
            if frequency_dict_word.get(i,0) <= hand.get(i,0):
                return True
            else:
                return False
    else:
        return False