def is_valid_word(word,hand,word_list):
    list_of_words = list(word)
    if '*' in word:
        wildCardPos = word.find('*')
        print"Wildcard found at : ", wildCardPos
           
        for wildcard in VOWELS: #wildcard takes a value of a,e,i,o,u
            list_of_words[wildCardPos] = wildcard
            new_word = ''.join(list_of_words)       
            frequency_dict_word = get_frequency_dict(new_word)       
            if new_word in word_list:
                for i in new_word:
                    if frequency_dict_word.get(i,0) <= hand.get(i,0):
                        return True
                    else:
                        return False
            else:
                return False
    else:
        if word in word_list:
            frequency_dict_word = get_frequency_dict(word)  
            for i in word:
                if frequency_dict_word.get(i,0) <= hand.get(i,0):
                    return True
                else:
                    return False
        else:
            return False
    