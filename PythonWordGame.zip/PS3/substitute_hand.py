def substitute_hand(hand, letter):
    letters = 'aeioubcdfghjklmnpqrstvwxyz'
    
    if letter not in hand:
        return hand
    else:
        to_pick = []
        freq = hand[letter]
        del(hand[letter])
        for i in letters:
            if i not in hand:
                to_pick.append(i)
    
        new_element = random.choice(to_pick)
        hand[new_element] = freq
        
        
    
    return hand